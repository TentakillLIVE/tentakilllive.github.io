# EightEyes Turbo Helper — Firefox Edition

A Firefox extension that lets **Twitch Turbo** subscribers watch embedded Twitch streams on EightEyes (and any other site) without ads.

---

## How it works

Unlike the Chrome version (which uses declarative rules), Firefox's extension platform supports **live request interception** via the `webRequest` blocking API. This means:

1. A listener is registered for every XHR/fetch request to `gql.twitch.tv`.
2. When the embedded player fires the `PlaybackAccessToken` GQL query, the listener intercepts it mid-flight and injects your `Authorization: OAuth <token>` header before it's sent.
3. Twitch's servers see an authenticated Turbo user and return an ad-free stream token.
4. No declarative rules, no race conditions, no startup sequencing issues.

Your auth token is read directly from your browser's `twitch.tv` cookie store. It never leaves your computer except in requests going directly to Twitch's own servers.

---

## Installation

### Temporary (for testing)
1. Open Firefox and go to `about:debugging`
2. Click **This Firefox**
3. Click **Load Temporary Add-on**
4. Select the `manifest.json` file inside this folder
5. The extension is active until you restart Firefox

### Permanent (via Firefox Add-ons)
For a permanent install without needing Developer Mode, the extension would need to be submitted to [addons.mozilla.org](https://addons.mozilla.org) for signing. Firefox requires all permanently installed extensions to be signed by Mozilla.

---

## Usage

- **Green dot** = You're logged in to Twitch and the interceptor is live.
- **Orange dot** = You're not logged in. Click "Sign in to Twitch", log in, then hit Refresh.

The extension automatically refreshes its cached token whenever Twitch cookies change.

---

## Permissions explained

| Permission | Why it's needed |
|---|---|
| `cookies` | Read your `auth-token` from `twitch.tv` |
| `webRequest` + `webRequestBlocking` | Intercept and modify GQL requests in real time |
| `storage` | Cache status so the popup loads instantly |
| `*://*.twitch.tv/*` | Scope all access to Twitch domains only |

---

## Differences from the Chrome version

| | Chrome | Firefox |
|---|---|---|
| Manifest version | MV3 | MV2 |
| Interception method | `declarativeNetRequest` (static rules) | `webRequest` blocking (live interception) |
| Race conditions | Possible on startup (mitigated with mutex) | None — listener-based, no rules to manage |
| Persistent background | Service worker (can sleep) | Persistent background script |
