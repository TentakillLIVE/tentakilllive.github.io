const statusCard     = document.getElementById('statusCard');
const statusDot      = document.getElementById('statusDot');
const statusLabel    = document.getElementById('statusLabel');
const statusSub      = document.getElementById('statusSub');
const refreshBtn     = document.getElementById('refreshBtn');
const twitchLoginBtn = document.getElementById('twitchLoginBtn');
const rulesGrid      = document.getElementById('rulesGrid');
const chipAuthVal    = document.getElementById('chipAuthVal');

function renderStatus({ active, login }) {
  statusCard.className = 'status-card ' + (active ? 'active' : 'inactive');
  statusDot.className  = 'status-dot '  + (active ? 'green'  : 'orange');

  if (active) {
    statusLabel.textContent = 'Protection Active';
    statusSub.innerHTML = `Logged in as <span class="login-name">@${login}</span>. Live request interceptor is injecting your auth token into all embedded Twitch GQL calls.`;
    twitchLoginBtn.style.display = 'none';
    rulesGrid.style.display = 'grid';
    chipAuthVal.textContent = `OAuth ${login}…`;
  } else {
    statusLabel.textContent = 'Not Active';
    statusSub.textContent   = 'Sign in to Twitch to enable Turbo ad-skipping in embedded players.';
    twitchLoginBtn.style.display = 'flex';
    rulesGrid.style.display = 'none';
  }
}

function setLoading() {
  statusCard.className    = 'status-card loading';
  statusDot.className     = 'status-dot gray';
  statusLabel.textContent = 'Checking…';
  statusSub.textContent   = '';
  rulesGrid.style.display = 'none';
}

setLoading();
browser.runtime.sendMessage({ type: 'GET_STATUS' }).then(renderStatus);

refreshBtn.addEventListener('click', () => {
  setLoading();
  browser.runtime.sendMessage({ type: 'REFRESH' }).then(() => {
    browser.runtime.sendMessage({ type: 'GET_STATUS' }).then(renderStatus);
  });
});
