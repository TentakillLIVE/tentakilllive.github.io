/**
 * EightEyes Turbo Helper — Firefox Background Script
 *
 * Firefox uses Manifest V2 with the webRequest blocking API, which lets us
 * intercept and modify request headers synchronously on a per-request basis.
 * This is fundamentally different from Chrome's declarativeNetRequest approach:
 *
 *  - No declarative rules to manage, so no race conditions on startup.
 *  - The listener fires for every matching request and injects the header live.
 *  - We cache the auth token in memory and refresh it when cookies change.
 *
 * Target: every XMLHttpRequest to gql.twitch.tv/gql from any origin.
 * Action: inject Authorization: OAuth <token> so Twitch identifies the user
 *         as a Turbo subscriber and returns an ad-free stream access token.
 */

// In-memory auth token cache — avoids an async cookie lookup on every request
let cachedAuthToken = null;
let cachedLogin     = null;

// ─── Token Cache Management ───────────────────────────────────────────────────

async function refreshCache() {
  try {
    const [authCookie, loginCookie] = await Promise.all([
      browser.cookies.get({ url: 'https://www.twitch.tv', name: 'auth-token' }),
      browser.cookies.get({ url: 'https://www.twitch.tv', name: 'login'       }),
    ]);

    cachedAuthToken = authCookie?.value  ?? null;
    cachedLogin     = loginCookie?.value ?? null;

    await browser.storage.local.set({
      status: { active: !!cachedAuthToken, login: cachedLogin }
    });

    console.log(cachedAuthToken
      ? `[EightEyes] Token cached for @${cachedLogin}`
      : '[EightEyes] No auth-token found — listener will pass requests through.'
    );
  } catch (err) {
    console.error('[EightEyes] refreshCache failed:', err);
  }
}

// ─── Request Interceptor ──────────────────────────────────────────────────────

/**
 * Fires synchronously for every XHR/fetch to gql.twitch.tv.
 * If we have a cached token, SET the Authorization header.
 * Returning the modified requestHeaders applies them before the request is sent.
 */
function onBeforeSendHeaders(details) {
  if (!cachedAuthToken) return {};

  const headers = details.requestHeaders.filter(
    h => h.name.toLowerCase() !== 'authorization'
  );

  headers.push({
    name:  'Authorization',
    value: `OAuth ${cachedAuthToken}`,
  });

  return { requestHeaders: headers };
}

// Register the blocking webRequest listener
browser.webRequest.onBeforeSendHeaders.addListener(
  onBeforeSendHeaders,
  {
    urls:  ['*://gql.twitch.tv/gql*'],
    types: ['xmlhttprequest'],
  },
  ['blocking', 'requestHeaders']
);

// ─── Cookie Change Listener ───────────────────────────────────────────────────

browser.cookies.onChanged.addListener(({ cookie }) => {
  if (
    cookie.domain.includes('twitch.tv') &&
    (cookie.name === 'auth-token' || cookie.name === 'login')
  ) {
    console.log(`[EightEyes] Cookie changed (${cookie.name}) — refreshing cache.`);
    refreshCache();
  }
});

// ─── Message Handler ──────────────────────────────────────────────────────────

browser.runtime.onMessage.addListener((message) => {
  if (message.type === 'GET_STATUS') {
    return Promise.resolve({
      active: !!cachedAuthToken,
      login:  cachedLogin,
    });
  }

  if (message.type === 'REFRESH') {
    return refreshCache().then(() => ({ ok: true }));
  }
});

// ─── Initialise ───────────────────────────────────────────────────────────────

refreshCache();
