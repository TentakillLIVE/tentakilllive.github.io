const statusCard     = document.getElementById('statusCard');
const statusDot      = document.getElementById('statusDot');
const statusLabel    = document.getElementById('statusLabel');
const statusSub      = document.getElementById('statusSub');
const refreshBtn     = document.getElementById('refreshBtn');
const twitchLoginBtn = document.getElementById('twitchLoginBtn');
const rulesGrid      = document.getElementById('rulesGrid');
const chipGql        = document.getElementById('chipGql');
const chipGqlVal     = document.getElementById('chipGqlVal');
const chipCookie     = document.getElementById('chipCookie');

function renderStatus({ active, login }) {
  statusCard.className = 'status-card ' + (active ? 'active' : 'inactive');
  statusDot.className  = 'status-dot '  + (active ? 'green'  : 'orange');

  if (active) {
    statusLabel.textContent = 'Protection Active';
    statusSub.innerHTML = `Logged in as <span class="login-name">@${login}</span>. GQL Authorization header + cookie injection are both live.`;
    twitchLoginBtn.style.display = 'none';
    rulesGrid.style.display = 'grid';
    chipGql.className    = 'rule-chip ok';
    chipGqlVal.textContent = `OAuth ${login}…`;
    chipCookie.className = 'rule-chip ok';
  } else {
    statusLabel.textContent = 'Not Active';
    statusSub.textContent   = 'Sign in to Twitch to enable Turbo ad-skipping in embedded players.';
    twitchLoginBtn.style.display = 'flex';
    rulesGrid.style.display = 'none';
  }
}

function setLoading() {
  statusCard.className    = 'status-card loading';
  statusDot.className     = 'status-dot gray';
  statusLabel.textContent = 'Checking…';
  statusSub.textContent   = '';
  rulesGrid.style.display = 'none';
}

setLoading();
chrome.runtime.sendMessage({ type: 'GET_STATUS' }, renderStatus);

refreshBtn.addEventListener('click', () => {
  setLoading();
  chrome.runtime.sendMessage({ type: 'REFRESH' }, () => {
    chrome.runtime.sendMessage({ type: 'GET_STATUS' }, renderStatus);
  });
});
