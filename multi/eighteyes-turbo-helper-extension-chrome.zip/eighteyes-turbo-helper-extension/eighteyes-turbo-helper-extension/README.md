# EightEyes Turbo Helper

A browser extension that lets **Twitch Turbo** subscribers watch embedded Twitch streams on EightEyes (and any other site) without ads.

---

## How it works

Modern browsers block third-party cookies by default, which means embedded Twitch players can't tell you're logged in — so they serve ads even if you have Turbo.

This extension sidesteps that limitation:

1. It reads your `auth-token` cookie directly from `twitch.tv` (extensions have elevated cookie access that web pages don't).
2. It uses the browser's `declarativeNetRequest` API to **inject your auth token** into the Cookie header on every request the embedded Twitch player makes to `*.twitch.tv`.
3. Twitch's servers now see you as a logged-in Turbo subscriber and skip ad delivery.

No proxies. No stream re-routing. No data ever leaves your browser.

---

## Installation (Chrome / Edge / Brave)

1. Open your browser and go to `chrome://extensions`
2. Enable **Developer Mode** (toggle in the top-right corner)
3. Click **Load unpacked**
4. Select the `eighteyes-extension` folder
5. The extension icon will appear in your toolbar

### Firefox
1. Go to `about:debugging`
2. Click **This Firefox → Load Temporary Add-on**
3. Select `manifest.json` inside the folder

> **Note for Firefox:** Temporary add-ons are removed on browser restart. For permanent installation, the extension would need to be signed via AMO.

---

## Usage

- **Green dot** = You're logged in to Twitch and the rule is active. Embeds on any site will be authenticated.
- **Orange dot** = You're not logged in to Twitch. Click "Sign in to Twitch", log in, then click "Refresh Status".

The extension automatically updates its rule whenever you log in or out of Twitch — no manual steps needed day-to-day.

---

## Permissions explained

| Permission | Why it's needed |
|---|---|
| `cookies` | Read your `auth-token` from `twitch.tv` |
| `declarativeNetRequest` | Inject the token into embedded Twitch requests |
| `storage` | Cache status so the popup loads instantly |
| `*://*.twitch.tv/*` | Scope the cookie read and header injection to Twitch only |

The extension **never** reads cookies from any other domain, and **never** sends data anywhere.

---

## Limitations

- Requires an active Twitch Turbo or Twitch Prime subscription — the extension authenticates you, but Twitch still decides whether your account is ad-free.
- If Twitch rotates its authentication cookie format, the extension may need an update.
- Does not affect streams playing on `twitch.tv` itself (only embedded contexts) — the browser already handles first-party cookies there normally.
