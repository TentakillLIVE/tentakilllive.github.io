/**
 * EightEyes Turbo Helper — Background Service Worker
 *
 * How it works:
 *   Twitch's pre-roll ad decision is made inside the GQL PlaybackAccessToken
 *   query, which fires before any video loads. When Twitch is embedded on
 *   another site the player sends no Authorization header, so Twitch treats
 *   the viewer as anonymous and serves ads regardless of Turbo status.
 *
 *   This extension intercepts every POST to gql.twitch.tv and injects
 *   Authorization: OAuth <token> using the auth-token read directly from
 *   the user's twitch.tv cookies. Twitch then recognises the Turbo account
 *   and returns a clean, ad-free stream access token.
 */

const RULE_ID = 1;

// ─── Mutex ────────────────────────────────────────────────────────────────────
// onInstalled and onStartup both fire on extension load, causing concurrent
// calls to updateRules(). Even a single atomic remove+add call isn't enough —
// if two invocations both reach updateDynamicRules() concurrently, Chrome sees
// both trying to add rule ID 1 and throws "ID not unique".
//
// This mutex chains every call onto the previous one so they run serially.
// A pending update is also deduplicated: if one is already queued, a second
// caller just reuses the same queued promise rather than stacking another.

let updateChain  = Promise.resolve(); // the serialisation chain
let updateQueued = false;             // true when a call is already waiting

function scheduleUpdate() {
  if (updateQueued) return;           // already one waiting — no need to queue another
  updateQueued = true;
  updateChain = updateChain.then(() => {
    updateQueued = false;
    return _doUpdate();
  });
}

// ─── Core Logic ───────────────────────────────────────────────────────────────

async function _doUpdate() {
  try {
    const [authCookie, loginCookie] = await Promise.all([
      chrome.cookies.get({ url: 'https://www.twitch.tv', name: 'auth-token' }),
      chrome.cookies.get({ url: 'https://www.twitch.tv', name: 'login'       }),
    ]);

    const authToken = authCookie?.value  ?? null;
    const login     = loginCookie?.value ?? null;

    // Get currently installed dynamic rules so we know whether rule ID 1
    // actually exists before trying to remove it. Passing a non-existent ID
    // to removeRuleIds is harmless, but this makes the intent explicit.
    const existing = await chrome.declarativeNetRequest.getDynamicRules();
    const existingIds = existing.map(r => r.id);

    if (!authToken) {
      if (existingIds.includes(RULE_ID)) {
        await chrome.declarativeNetRequest.updateDynamicRules({
          removeRuleIds: [RULE_ID],
        });
      }
      await chrome.storage.local.set({ status: { active: false, login: null } });
      console.log('[EightEyes] No auth-token — rule cleared.');
      return;
    }

    // Remove (if present) and add in a single atomic call.
    await chrome.declarativeNetRequest.updateDynamicRules({
      removeRuleIds: existingIds.includes(RULE_ID) ? [RULE_ID] : [],
      addRules: [
        {
          id: RULE_ID,
          priority: 1,
          action: {
            type: 'modifyHeaders',
            requestHeaders: [
              { header: 'Authorization', operation: 'set', value: `OAuth ${authToken}` },
            ],
          },
          condition: {
            urlFilter: '||gql.twitch.tv/gql',
            resourceTypes: ['xmlhttprequest'],
          },
        },
      ],
    });

    await chrome.storage.local.set({ status: { active: true, login } });
    console.log(`[EightEyes] Rule active — Authorization injected for @${login}`);

  } catch (err) {
    console.error('[EightEyes] updateRules failed:', err);
    await chrome.storage.local.set({ status: { active: false, login: null, error: err.message } });
  }
}

// ─── Event Listeners ──────────────────────────────────────────────────────────

chrome.runtime.onInstalled.addListener(scheduleUpdate);
chrome.runtime.onStartup.addListener(scheduleUpdate);

chrome.cookies.onChanged.addListener(({ cookie }) => {
  if (cookie.domain.includes('twitch.tv') &&
     (cookie.name === 'auth-token' || cookie.name === 'login')) {
    console.log(`[EightEyes] Cookie changed (${cookie.name}) — scheduling rule update.`);
    scheduleUpdate();
  }
});

chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
  if (message.type === 'GET_STATUS') {
    Promise.all([
      chrome.cookies.get({ url: 'https://www.twitch.tv', name: 'auth-token' }),
      chrome.cookies.get({ url: 'https://www.twitch.tv', name: 'login'       }),
    ]).then(([tokenCookie, loginCookie]) => {
      sendResponse({ active: !!tokenCookie?.value, login: loginCookie?.value ?? null });
    });
    return true; // keep message channel open for async response
  }

  if (message.type === 'REFRESH') {
    scheduleUpdate();
    // Wait for the current chain to settle before replying
    updateChain.then(() => sendResponse({ ok: true }));
    return true;
  }
});
